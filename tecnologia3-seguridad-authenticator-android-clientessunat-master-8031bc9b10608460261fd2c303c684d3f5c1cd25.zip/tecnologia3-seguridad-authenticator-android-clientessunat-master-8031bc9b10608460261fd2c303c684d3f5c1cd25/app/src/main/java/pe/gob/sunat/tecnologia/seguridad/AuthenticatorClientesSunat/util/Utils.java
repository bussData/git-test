package pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.util;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.util.Base64;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class Utils {

    public static boolean rucValido(String ruc) {

        int dig01=Integer.parseInt(ruc.substring(0,1))*5;
        int dig02=Integer.parseInt(ruc.substring(1,2))*4;
        int dig03=Integer.parseInt(ruc.substring(2,3))*3;
        int dig04=Integer.parseInt(ruc.substring(3,4))*2;
        int dig05=Integer.parseInt(ruc.substring(4,5))*7;
        int dig06=Integer.parseInt(ruc.substring(5,6))*6;
        int dig07=Integer.parseInt(ruc.substring(6,7))*5;
        int dig08=Integer.parseInt(ruc.substring(7,8))*4;
        int dig09=Integer.parseInt(ruc.substring(8,9))*3;
        int dig10=Integer.parseInt(ruc.substring(9,10))*2;
        int dig11=Integer.parseInt(ruc.substring(10,11));

        int suma=dig01 + dig02 + dig03 + dig04 + dig05 + dig06 + dig07 + dig08 + dig09 + dig10;
        int residuo = suma%11;
        int resta = 11 - residuo;

        int digChk = 0;
        if (resta == 10)       {digChk = 0;    }
        else if (resta == 11)  {digChk = 1;    }
        else                   {digChk = resta;}

        if (dig11 == digChk)   {
            return true;
        }
        else {
            return false;
        }
    }

    public static int updateToken(ContentResolver resolver, Uri uri, String usuario, String token){
        ContentValues conValues = new ContentValues();
        String selectionClause = " usuario LIKE ?";
        String uUsuario = usuario+"%";
        String[] selectionArgs = {uUsuario};
        conValues.put("token",token);
        int rowsUpdated = resolver.update(uri, conValues, selectionClause, selectionArgs);
        return rowsUpdated;
    }

    public static int delete(ContentResolver resolver,Uri uri,String usuario){


        String selectionClause = " usuario LIKE ?";
        String uUsuario = usuario+"%";
        String[] selectionArgs = {uUsuario};
        int rowsDeleted = resolver.delete(uri, selectionClause, selectionArgs);
        return rowsDeleted;
    }

    public static  String decodedjwt(String JWTEncoded,String campo) throws Exception {

        String rs="";
        try {
            String[] split = JWTEncoded.split("\\.");
            String jsonbody= getJson(split[1]);
            JSONObject obj = new JSONObject(jsonbody);
            JSONObject x = new JSONObject(obj.getString("userdata"));
            rs= x.getString(campo);
        } catch (UnsupportedEncodingException e) {
            e.getStackTrace();
        }
        return rs;
    }

    private static String getJson(String strEncoded) throws UnsupportedEncodingException{
        byte[] decodedBytes = Base64.decode(strEncoded, Base64.URL_SAFE);
        return new String(decodedBytes, "UTF-8");
    }

    public static String generaRuc(String dni){
        String wtmp= "10"+ dni;
        String wnit = wtmp+ String.valueOf(mrs51200Digit11(wtmp));
        return wnit;
    }

    public static  int mrs51200Digit11(String cadena) {
        int wresto = 0;
        cadena = cadena.trim();
        if (cadena.trim().length() == 10) {
            wresto = (2 * Integer.parseInt(cadena.substring(9, 10)))
                    + (3 * Integer.parseInt(cadena.substring(8, 9)))
                    + (4 * Integer.parseInt(cadena.substring(7, 8)))
                    + (5 * Integer.parseInt(cadena.substring(6, 7)))
                    + (6 * Integer.parseInt(cadena.substring(5, 6)))
                    + (7 * Integer.parseInt(cadena.substring(4, 5)))
                    + (2 * Integer.parseInt(cadena.substring(3, 4)))
                    + (3 * Integer.parseInt(cadena.substring(2, 3)))
                    + (4 * Integer.parseInt(cadena.substring(1, 2)))
                    + (5 * Integer.parseInt(cadena.substring(0, 1)));
            wresto = wresto % 11;
            wresto = 11 - wresto;
            if (wresto >= 10) {
                wresto = wresto - 10;
            }
        }
        return wresto;
    }






}
