package pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.service;

import android.content.Context;

public class ApiUtils {

    private ApiUtils() {
    }



    //public static final String BASE_URL = "https://api-seguridad.sunat.gob.pe/";                //  EMULADOR LOCAL
    public static final String BASE_URL = "https://api-seguridad-desa.sunat.gob.pe:444/";     //  CELULAR DESARROLLO
    //public static final String BASE_URL = "https://api-seguridad-test.sunat.gob.pe:444/";              //  CELULAR CALIDAD
    //public static final String BASE_URL = "https://api-seguridad.sunat.gob.pe/";              //  CELULAR PRODUCCION
    //public static final String BASE_URL = "http://10.0.2.2:7138/";                            // LOCALHOST


    public static final String KEY_CLIENT_ID = "clientId"; //Nombre del identificador del client_id
    public static final String KEY_CLIENT_SECRET = "clientSecret"; //Nombre del identificador del client_secret
    public static final String GRANTYPE = "password";
    public static final String GRANTYPE_REFRESH = "authorization_token";
    public static final String SCOPE = "scope";
    public static final String CLIENT_ID_AUTHENTICATOR ="2f7ed43e-764b-42cc-af53-e7149ec18955";
    public static final String CLIENT_SECRET_AUTHENTICATOR = "fQzGejFzWmHgjsazkqNU+Zd6P24MSSBDlMvBZ+vgk7";


    public static APIService getAPIService(Context context) {

        return RetrofitClient.getClient(BASE_URL, context).create(APIService.class);
    }


}
