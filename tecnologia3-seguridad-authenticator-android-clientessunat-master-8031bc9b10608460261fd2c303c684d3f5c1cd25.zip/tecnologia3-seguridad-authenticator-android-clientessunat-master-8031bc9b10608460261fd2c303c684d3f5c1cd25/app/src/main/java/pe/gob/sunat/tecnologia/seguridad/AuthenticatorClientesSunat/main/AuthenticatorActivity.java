package pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.main;


import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.R;
import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.bean.TokenResponse;
import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.model.EstructuraDatos;
import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.service.APIService;
import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.service.ApiUtils;
import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.util.Constantes;

import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.util.Utils;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;



public class AuthenticatorActivity extends AppCompatActivity {

    private final String TAG = "AuthenticatorActivity";
    private static final String KEY_APLICATION_PRINCIPAL = "rutaApp";       //Nombre que debe definirse en el app que consuma el authenticator
    private static final String KEY_CLIENT_ID = "clientId";      //Nombre que debe definirse en el app que consuma el authenticator
    private static final String KEY_CLIENT_SECRET = "clientSecret";  //Nombre que debe definirse en el app que consuma el authenticator

    private String authtoken,refreshtoken,pUser, pPass,msgError,app="",tokeninapp="",user="",client_id,client_secret,client_id_ext,client_secret_ext;

    private APIService mAPIService;
    private View v;
    private Cursor c;
    String[] projection = new String[] {"_id","usuario","token" };
    public static final Uri CONTENT_URI = Uri.parse("content://pe.gob.sunat.authenticatorClientesSunat.provider/UsersClientesSunat");
    private ProgressBar pgsBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_authenticator);

        app = getIntent().getStringExtra(KEY_APLICATION_PRINCIPAL);     //PAQUETE DEL APP A REDIRIGIR
        client_id_ext = getIntent().getStringExtra(KEY_CLIENT_ID);          //CLIENT ID DEL APP A REDIRIGIR
        client_secret_ext = getIntent().getStringExtra(KEY_CLIENT_SECRET);  //CLIENT SECRET DEL APP A REDIRIGIR

        //VERIFICAMOS SI YA EXISTE TOKEN DEL AUTHENTICADOR ALMACENADO
        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(CONTENT_URI,
                projection,             //Columnas a devolver
                null,           //Condición de la query
                null,       //Argumentos variables de la query
                null);

        if (cur != null){
            if (cur.moveToFirst()) {

                tokeninapp = cur.getString(cur.getColumnIndex("token"));
                user = cur.getString(cur.getColumnIndex("usuario"));

                //Si viene del mismo autenticador
                if(app==null){

                    Intent i=new Intent(this,DatosActivity.class);
                    i.putExtra("token",tokeninapp);
                    startActivity(i);
                    finish();
                }
                //Si viene de una app externa
                else{
                    canjearToken(ApiUtils.GRANTYPE_REFRESH,client_id_ext,client_secret_ext,tokeninapp,user);

                }
            }
        }



        //si no tiene token el autenticador
        if(tokeninapp.equalsIgnoreCase("")){
            setContentView(R.layout.activity_authenticator);

            mAPIService = ApiUtils.getAPIService(getApplicationContext());
            pgsBar  =(ProgressBar) findViewById(R.id.p2Bar);

            final EditText frUser = (EditText) findViewById(R.id.txtUsuario);
            final EditText frPass = (EditText) findViewById(R.id.txtPassword);

            findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    client_id = ApiUtils.CLIENT_ID_AUTHENTICATOR;
                    client_secret = ApiUtils.CLIENT_SECRET_AUTHENTICATOR;

                    pUser = frUser.getText().toString().trim();
                    pPass = frPass.getText().toString().trim();

                    /*VALIDACION ERROR*/
                    if(pUser.isEmpty()){
                        frUser.requestFocus();
                        Toast.makeText(getBaseContext(), Constantes.ERROR_USUARIO,Toast.LENGTH_LONG ).show();
                    } else if(pPass.isEmpty()) {
                        frPass.requestFocus();
                        Toast.makeText(getBaseContext(), Constantes.ERROR_PASSWORD, Toast.LENGTH_LONG).show();
                    }else if(pPass.length()<6){
                        frPass.requestFocus();
                        Toast.makeText(getBaseContext(), Constantes.ERROR_PASSWORD_LENGTH,Toast.LENGTH_LONG ).show();
                    }else{
                        pgsBar.setVisibility(v.VISIBLE);
                        obtenerTokenServer(client_id, ApiUtils.GRANTYPE, ApiUtils.SCOPE, client_id, client_secret, pUser, pPass);
                    }

                }
            });
        }


    }

    public void obtenerTokenServer(String pathClientId, String grantType, String scope,
                                   final String clientId, String clientSecret, final String username, String password) {


        mAPIService.getToken(pathClientId, grantType, scope, clientId, clientSecret, username, password).enqueue(new Callback<TokenResponse>() {

            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {

                if (response.isSuccessful()) {

                    authtoken = response.body().getAccessToken();
                    checkdata(username,authtoken);
                    Log.i(TAG," Respuesta : OK ->"+ response.code()+" "+ApiUtils.BASE_URL+"/v1/clientessunat/"+clientId+"/oauth2/token/");
                    Long tsLong = System.currentTimeMillis()/1000;
                    String ts = tsLong.toString();
                    Log.i(TAG,"TIEMPO: "+ts);

                }else{
                   // MONITOREO DE ERRORES

                    switch (response.code()){

                        case 400: msgError =  Constantes.ERROR_400;break;
                        case 401: msgError =  Constantes.ERROR_401;break;
                        case 404: msgError =  Constantes.ERROR_404;break;
                        default:  msgError =  Constantes.ERROR_400;break;
                    }

                    pgsBar.setVisibility(v.GONE);
                    Toast.makeText(getBaseContext(), msgError,Toast.LENGTH_LONG ).show();
                    Log.e(TAG," Respuesta : ERROR ->"+ response.code()+" "+ApiUtils.BASE_URL+"/v1/clientessunat/"+clientId+"/oauth2/token/");
                }
            }

            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {
                msgError= Constantes.ERROR_SERVICIO+t.getMessage();
                pgsBar.setVisibility(v.GONE);
                Toast.makeText(getBaseContext(), msgError,Toast.LENGTH_LONG ).show();
                t.printStackTrace();
                Log.e(TAG," Respuesta : FALLA ->"+ msgError+" "+ApiUtils.BASE_URL+"/v1/clientessunat/"+clientId+"/oauth2/token/");
            }

        });


    }

    private void checkdata(String usuario,String token) {

        ContentResolver cr = getContentResolver();
        //BORRAMOS LA CUENTA
        int ndelete=Utils.delete(cr,CONTENT_URI,usuario);
        if(ndelete>0){
            Log.i(TAG,"Se borraron los registros de: "+usuario);
        }
        //Insertamos token de autenticación
        ContentValues values = new ContentValues();
        values.put(EstructuraDatos.COLUMN_NAME_USUARIO, usuario);
        values.put(EstructuraDatos.COLUMN_NAME_TOKEN, token);
        cr.insert(CONTENT_URI, values);

        //lanza app externa
        if(app!=null){
            canjearToken(ApiUtils.GRANTYPE_REFRESH,client_id_ext,client_secret_ext,token,usuario);

        }
        //Lanza datos activity
        else{
            Intent i=new Intent(this,DatosActivity.class);
            i.putExtra("usuario",usuario);
            i.putExtra("token",token);
            startActivity(i);
            finish();
        }

        Toast.makeText(this, "REGISTRO EXITOSO" , Toast.LENGTH_LONG).show();
        pgsBar.setVisibility(v.GONE);
    }

    public void canjearToken(String grant_type, final String client_id, String client_secret, String token, final String usuario){

        mAPIService = ApiUtils.getAPIService(getApplicationContext());
        mAPIService.getTokenRefresh(client_id, grant_type, client_id, client_secret, token).enqueue(new Callback<TokenResponse>() {

            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {

                if (response.isSuccessful()) {

                    refreshtoken = response.body().getAccessToken();
                    Intent auth =getPackageManager().getLaunchIntentForPackage(app);
                    auth.putExtra("usuario",usuario);
                    auth.putExtra("token",refreshtoken);
                    startActivity(auth);
                    finish();
                    Log.i(TAG," Respuesta : OK ->"+ response.code()+" "+ApiUtils.BASE_URL+"/v1/clientessunat/"+client_id_ext+"/oauth2/token/");

                }else{
                    // MONITOREO DE ERRORES
                    switch (response.code()){
                        case 400: msgError =  Constantes.ERROR_400;break;
                        case 401: msgError =  Constantes.ERROR_401;break;
                        case 404: msgError =  Constantes.ERROR_404;break;
                        default:  msgError =  Constantes.ERROR_400;break;
                    }

                    pgsBar.setVisibility(v.GONE);
                    Toast.makeText(getBaseContext(), msgError,Toast.LENGTH_LONG ).show();
                    Log.e(TAG," Respuesta : ERROR ->"+ response.code()+" "+ApiUtils.BASE_URL+"/v1/clientessunat/"+client_id_ext+"/oauth2/token/");
                }
            }

            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {
                msgError= Constantes.ERROR_SERVICIO+t.getMessage();
                pgsBar.setVisibility(v.GONE);
                Toast.makeText(getBaseContext(), msgError,Toast.LENGTH_LONG ).show();
                t.printStackTrace();
                Log.e(TAG," Respuesta : FALLA ->"+ msgError+" "+ApiUtils.BASE_URL+"/v1/clientessunat/"+client_id_ext+"/oauth2/token/");
            }

        });

    }


}


