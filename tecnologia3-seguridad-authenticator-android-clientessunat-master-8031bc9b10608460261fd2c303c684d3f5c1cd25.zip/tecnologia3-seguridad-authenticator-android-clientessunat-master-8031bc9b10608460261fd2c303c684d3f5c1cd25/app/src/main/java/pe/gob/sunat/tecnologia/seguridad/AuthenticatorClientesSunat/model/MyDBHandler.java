package pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class MyDBHandler extends SQLiteOpenHelper {

    /*Se declara e inicializa una variable encargada de controlar el tipo de dato
    de cada columna de la tabla.*/
    private static final String TEXT_TYPE = " TEXT";

    /*Crear Tabla */

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + EstructuraDatos.TABLE_NAME + " (" +
                    EstructuraDatos._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    EstructuraDatos.COLUMN_NAME_USUARIO + TEXT_TYPE + ", " +
                    EstructuraDatos.COLUMN_NAME_TOKEN + TEXT_TYPE + ")";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + EstructuraDatos.TABLE_NAME;

    public static final int DATABASE_VERSION = 1;

    public static final String DATABASE_NAME = "AuthenticatorFuncionarios.sqlite";

    public MyDBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /*Método que recibe la consulta Transact-SQL para para crear la Tabla.*/
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    /*Método que elimina la tabla y vuelve a invocar al método que la crea.*/
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}
