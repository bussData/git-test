package pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.service;

import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.bean.TokenResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface APIService {

    @POST("/v1/clientessunat/{path_client_id}/oauth2/token/")
    @FormUrlEncoded
    Call<TokenResponse> getToken(@Path("path_client_id") String pathClientId, @Field("grant_type") String grantType,
                                 @Field("scope") String scope, @Field("client_id") String clientId, @Field("client_secret") String clientSecret,
                                 @Field("username") String username, @Field("password") String password);

    @POST("/v1/clientessunat/{path_client_id}/oauth2/token/")
    @FormUrlEncoded
    Call<TokenResponse> getTokenRefresh(@Path("path_client_id") String pathClientId, @Field("grant_type") String grantType,
                                        @Field("client_id") String clientId, @Field("client_secret") String clientSecret,
                                        @Field("auth_token") String authtoken);

}
