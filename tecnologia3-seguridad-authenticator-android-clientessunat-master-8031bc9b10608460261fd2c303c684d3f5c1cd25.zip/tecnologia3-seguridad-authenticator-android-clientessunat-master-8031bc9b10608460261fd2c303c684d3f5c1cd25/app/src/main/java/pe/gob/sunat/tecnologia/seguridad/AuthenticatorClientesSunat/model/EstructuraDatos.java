package pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.model;


import android.provider.BaseColumns;

/*Clase EstructuraDatos, que implementa la interfaz BaseColumns, que permite declarar e inicializar
las variables que definen el nombre de la tabla y los campos creados.*/
public class EstructuraDatos implements BaseColumns {

    public static final String TABLE_NAME = "UsersClientesSunat";
    public static final String COLUMN_NAME_USUARIO = "usuario";
    public static final String COLUMN_NAME_TOKEN = "token";
}

