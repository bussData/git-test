package pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.util;

public class Constantes {

    public static final String ERROR_USUARIO = "Ingresar la información del usuario, posiblemente el campo está vacío";
    public static final String ERROR_USUARIO_LENGTH = "La longitud del usuario es incorrecto, deben ser 8 caracteres";

    public static final String ERROR_PASSWORD = "Ingresar la contraseña, posiblemente el campo esté vacío";
    public static final String ERROR_PASSWORD_LENGTH = "La longitud del password es incorrecto, deben ser minimo 6 caracteres";

    public static final String ERROR_401 = "Error 401 -> No tiene Autorización para el ingreso";
    public static final String ERROR_404 = "Error 404 -> Not Found";
    public static final String ERROR_400  = "Error en la Autenticación del usuario y/o ingreso no autorizado";

    public static final String ERROR_SERVICIO="Error en el servicio ";

}
