package pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.main;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.R;
import pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.util.Utils;



public class DatosActivity extends AppCompatActivity {

    private final String TAG = "DatosActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datos_activity);
        TextView frNombre = (TextView) findViewById(R.id.txtnombre);
        TextView frCorreo = (TextView) findViewById(R.id.txtcorreo);
        TextView frNroregistro = (TextView) findViewById(R.id.txtnroregistro);
        String token = getIntent().getStringExtra("token");
        try {

            frNombre.setText(Utils.decodedjwt(token,"nombreCompleto"));
            frCorreo.setText(Utils.decodedjwt(token,"correo"));
            frNroregistro.setText(Utils.decodedjwt(token,"nroRegistro"));
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG,e.getMessage());
        }

    }


}


