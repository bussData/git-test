package pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat.model;



import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

/*Clase SunatContentProvider, que hereda de la clase base ContentProvider, encargada de
establecer los mecanismos necesarios para intercambiar información con el resto de aplicaciones.*/
public class SunatContentProvider extends ContentProvider {

    //private static final String AUTORIDAD = "com.sunat.listadeusuarios.SunatContentProvider";
    private static final String AUTORIDAD = "pe.gob.sunat.authenticatorClientesSunat.provider";
    /*Se declara e inicializa una constante de la clase Uri, que recogerá la URI
    que identificará de manera única el Content Provider .*/

    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTORIDAD + "/" + EstructuraDatos.TABLE_NAME);
    private static final int CLIENTES = 1;
    private static final int CLIENTES_ID = 2;
    private SQLiteDatabase db;
    MyDBHandler datos;
    private static final UriMatcher uriMatcher;

    /*Se inicializa la clase UriMatcher, para definir los tipos de URI,
    y poder devolvernos su tipo.*/
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(AUTORIDAD, EstructuraDatos.TABLE_NAME, CLIENTES);
        uriMatcher.addURI(AUTORIDAD, EstructuraDatos.TABLE_NAME + "/#", CLIENTES_ID);
    }

    /*Array de Strings, con todos los campos existentes en la tabla Clientes.*/
    public static String[] columnas = new String[]{
            EstructuraDatos._ID,
            EstructuraDatos.COLUMN_NAME_USUARIO,
            EstructuraDatos.COLUMN_NAME_TOKEN
    };



    @Override
    public String getType(Uri uri) {
        return null;
    }



    /*Método donde se inicializa la base de datos SQLite utilizada para el Content Provider.*/
    @Override
    public boolean onCreate() {
        datos = new MyDBHandler(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {

        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
        queryBuilder.setTables(EstructuraDatos.TABLE_NAME);

        SQLiteDatabase db = datos.getReadableDatabase();

        int uriType = uriMatcher.match(uri);

        switch (uriType) {
            case CLIENTES_ID:
                queryBuilder.appendWhere(EstructuraDatos._ID + "="
                        + uri.getLastPathSegment());
                break;
            case CLIENTES:
                break;
            default:
                throw new IllegalArgumentException("Unknown URI");
        }

        Cursor cursor = queryBuilder.query(db,
                projection, selection, selectionArgs, null, null, sortOrder);

        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }


    @Override
    public Uri insert(Uri uri, ContentValues values) {
        long regId = 1;
        SQLiteDatabase db = datos.getWritableDatabase();
        regId = db.insert(EstructuraDatos.TABLE_NAME, null, values);
        Uri newUri = ContentUris.withAppendedId(CONTENT_URI, regId);
        return newUri;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {

        int uriType = uriMatcher.match(uri);
        SQLiteDatabase sqlDB = datos.getWritableDatabase();
        int rowsUpdated = 0;

        switch (uriType) {
            case CLIENTES:
                rowsUpdated = sqlDB.update(EstructuraDatos.TABLE_NAME,
                        values,
                        selection,
                        selectionArgs);
                break;
            case CLIENTES_ID:
               /* String id = uri.getLastPathSegment();
                if (TextUtils.isEmpty(selection)) {
                    rowsUpdated =
                            sqlDB.update(MyDBHandler.TABLE_PRODUCTS,
                                    values,
                                    MyDBHandler.COLUMN_ID + "=" + id,
                                    null);
                } else {
                    rowsUpdated =
                            sqlDB.update(MyDBHandler.TABLE_PRODUCTS,
                                    values,
                                    MyDBHandler.COLUMN_ID + "=" + id
                                            + " and "
                                            + selection,
                                    selectionArgs);
                }*/
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return rowsUpdated;
    }


    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {

        int uriType = uriMatcher.match(uri);
        SQLiteDatabase sqlDB = datos.getWritableDatabase();
        int rowsDeleted = 0;

        switch (uriType) {
            case CLIENTES:
                rowsDeleted = sqlDB.delete(EstructuraDatos.TABLE_NAME,
                        selection,
                        selectionArgs);
                break;

            case CLIENTES_ID:
               /* String id = uri.getLastPathSegment();
                if (TextUtils.isEmpty(selection)) {
                    rowsDeleted = sqlDB.delete(MyDBHandler.TABLE_PRODUCTS,
                            MyDBHandler.COLUMN_ID + "=" + id,
                            null);
                } else {
                    rowsDeleted = sqlDB.delete(MyDBHandler.TABLE_PRODUCTS,
                            MyDBHandler.COLUMN_ID + "=" + id
                                    + " and " + selection,
                            selectionArgs);
                }*/
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return rowsDeleted;

    }
}
