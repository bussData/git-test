var ReporteEjecutivoVuceApp = angular.module('ReporteEjecutivoVuceApp', []);
ReporteEjecutivoVuceApp.config(['$routeProvider', function($routes) {

    $routes
        .when('/form_reporteejecutivovuce', {
            templateUrl	: '/a/js/sigad/controladuanero2/ingreso/vuce/reporteejecutivo/components/FormReporteEjecutivoVuce.html',
            controller 	: 'ReporteEjecutivoController'
        })
        .otherwise({
            redirectTo: '/form_reporteejecutivovuce'
        });
}]);
 var dateTimePicker = function($filter) {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attrs, ngModelCtrl) {
            var parent = $(element).parent();
            var dtp = parent.datetimepicker({
                format: "L", 
				language: 'es-PE', 
                pickTime: false					
            });

            ngModelCtrl.$formatters.unshift(function(v) {
                return $filter('date')(v,'dd/MM/yyyy'); 
            });

            if (ngModelCtrl) {
                ngModelCtrl.$render = function () {
                    setPickerValue();
                };
            }

            function setPickerValue() {
                var date = new Date();
                if (ngModelCtrl && ngModelCtrl.$viewValue) {
                    date = ngModelCtrl.$viewValue;
                }

                dtp.data('DateTimePicker').setDate(date);
            }

            dtp
            .on("dp.change", function (ev) {
                if (ngModelCtrl) {
                    ngModelCtrl.$setViewValue(moment(ev.date));    
                }
            })
            .datetimepicker();
        }
    };
}


var modalShow = function ($parse) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.showModal = function (visible, elem) {
                if (!elem)
                    elem = element;

                if (visible){
                    $(elem).modal({
                        "show" : true,
						backdrop : 'static',
						keyboard: false
                    }); 
                } else {
                    $(elem).modal("hide");
                }
            }

            //Watch for changes to the modal-visible attribute
            scope.$watch(attrs.modalShow, function (newValue, oldValue) {
                scope.showModal(newValue, attrs.$$element);
            });

            //Update the visible value when the dialog is closed through UI actions (Ok, cancel, etc.)
            $(element).bind("hide.bs.modal", function () {
                $parse(attrs.modalShow).assign(scope, false);
                if (!scope.$$phase && !scope.$root.$$phase)
                    scope.$apply();
            });
        }

    };
}
ReporteEjecutivoVuceApp.directive("modalShow", modalShow);
ReporteEjecutivoVuceApp.directive('dateTimePicker', dateTimePicker);
