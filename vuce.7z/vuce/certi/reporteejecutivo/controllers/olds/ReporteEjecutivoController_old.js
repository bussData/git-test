﻿'use strict';

function ReporteEjecutivoController($scope, $http, $location , $filter) {
    var  oTable;
	var cantDef =0 ;
	var cant = 0;	
	var mes="";
	var dia="";
	var cabeceras=[];
	var cols=[];
	$scope.showDialog = false;			 
	
    $scope.cargarEntidades = function(){
        $http.get('./reporteejecutivo/getEntidades').then(function(res){
            $scope.entidades = res.data;
        })
    }

    $scope.cargarSubEntidades = function(codEntidad){
        $http.get('./reporteejecutivo/getSubEntidades', {params : {'codElemento' : codEntidad}}).then(function(res){
            $scope.subentidades = res.data;
        })
    }

    $scope.cargarCuts = function(){
        $http.get('./reporteejecutivo/getCuts').then(function(res){
            $scope.cuts = res.data;
        })
    }

    $scope.cargarTipoDocumento = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/vuce/json/75.json').then(function(response){
            $scope.tiposDocumento = response.data;
        })
    } 
	
	$scope.cargarAduana = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/vuce/json/00.json').then(function(response){
            $scope.aduanas = response.data;      
        })
    }
 
	$scope.cargarPeriodo = function(){
		$scope.periodos = [{"codigo":"M","descripcion":"Mensual"},{"codigo":"D","descripcion":"Diario"}]; 
	}
 
	$scope.cargarTipoReporte = function(){	
		$scope.tiposReporte = 
			[{"codigo":"reporteA","descripcion":"Cantidad de documentos de control remitidos por la VUCE"}, 
			{"codigo":"reporteB","descripcion":"Cantidad de documentos de control VUCE vinculados a declaraciones"},
			{"codigo":"reporteC","descripcion":"Cantidad de declaraciones asociadas a documentos de control VUCE"},
			{"codigo":"reporteD","descripcion":"Cantidad de declaraciones remitidas a VUCE"}]; 
	}
 
	$scope.cargarNivelesDetalle = function(){
		$scope.nivelesDetalle =
			[{"codigo":"detalleE", "descripcion":"Entidad"},
			{"codigo":"detalleS", "descripcion":"Subentidad"},
			{"codigo":"detalleC", "descripcion":"CUT"}];	 
	}
											
    $scope.cargarDatosDefaultReporteEjecutivoForm = function(){
        $http.get('./reporteejecutivo/cargarDatosDefaultReporteEjecutivoForm?rnd='+new Date().getTime())
            .then(function(res){
                $scope.reporteEjecutivo = res.data;
				$scope.reporteEjecutivo.fechaDesde = new Date();				
				$scope.reporteEjecutivo.fechaHasta = new Date(); 
			});
    }
  
    
	$scope.limpiarTabla = function(){
        oTable.clear();
        oTable.draw();
    }
	
	//depuracion de cabecera de periodo mensual o diario
	$scope.limpiarCabeceraperiodos = function(){
		var cabeceraReporte = $("#headReporte");
		cabeceraReporte.children().remove(); 		
	}
	
	$scope.limpiar = function(){
		$scope.reporteEjecutivo.periodo="M";
		$scope.reporteEjecutivo.codEntidad= "00";
		$scope.reporteEjecutivo.codSubEntidad= "00";
		$scope.reporteEjecutivo.tipoReporte="";
		$scope.reporteEjecutivo.nivelDetalle="detalleE"; 	 	
        $scope.reporteEjecutivo.fechaDesde =  moment(new Date());//new Date();    
        $scope.reporteEjecutivo.fechaHasta = moment(new Date());//new Date(); 
		
		$scope.mostrarMsj = false;		
		$scope.msjValidacion = "";
		$scope.mostrarExport = false;  
		$scope.limpiarCabeceraperiodos();
		
		
		if ( $.fn.dataTable.isDataTable( '#tableReporteEjecutivo' ) ) {
			oTable = $('#tableReporteEjecutivo').DataTable();
			$scope.limpiarTabla();
		}
		
      
	}
 
	
	$scope.validarFormulario = function(){	
		$scope.mostrarMsj = false;
		$scope.msjValidacion = "";
		
		//validacion de fechas:
		var fechaDesdeForm = $scope.reporteEjecutivo.fechaDesde;
		var fechaHastaForm = $scope.reporteEjecutivo.fechaHasta;				 
		if(moment(fechaDesdeForm).isAfter(fechaHastaForm)){
			$scope.mostrarMsj = true;
			$scope.msjValidacion = "La fecha inicial de búsqueda debe ser menor a la fecha de fin";
			return false;
		}  
		
		//validacion de plazos para periodo:
		
		var cantdiasmaxMensual = 365; 
		var cantdiasmaxDiario = 31;		
			
		var fechaMaxDiario = moment(fechaDesdeForm,"DD/MM/YYYY").add(cantdiasmaxDiario-1, 'day'); //moment(fechaDesdeForm, "DD-MM-YYYY").add(cantdiasmaxDiario, 'days'); 
		var fechaMaxMensual = moment(fechaDesdeForm, "DD/MM/YYYY").add(cantdiasmaxMensual, 'day');//moment(fechaDesdeForm, "DD-MM-YYYY").add(cantdiasmaxMensual, 'days');
		 		
		if($scope.reporteEjecutivo.periodo == "D" && moment(fechaHastaForm).isAfter(fechaMaxDiario)){
			$scope.mostrarMsj = true;
			$scope.msjValidacion = "Para el periodo diario el rango de la fecha de búsqueda es máximo de "+cantdiasmaxDiario+" días, la fecha máxima de búsqueda debe ser "+fechaMaxDiario.format("DD/MM/YYYY"); 
			return false;
		}
		if($scope.reporteEjecutivo.periodo == "M" && moment(fechaHastaForm).isAfter(fechaMaxMensual)){
			$scope.mostrarMsj = true;
			$scope.msjValidacion = "Para el periodo mensual el rango de la fecha de búsqueda es máximo de "+cantdiasmaxMensual+" días, la fecha máxima de búsqueda debe ser "+ fechaMaxMensual.format("DD/MM/YYYY"); 
			return false;
		}		
		
		//validacion de tipo de reporte:
		if($scope.reporteEjecutivo.tipoReporte == undefined || $scope.reporteEjecutivo.tipoReporte == ""){
			$scope.mostrarMsj = true;
			$scope.msjValidacion = "Debe consignar un tipo de reporte.";
			return false;
		}	
	}
	 
	
    $scope.consultar  = function() {
	
		/*borrado cabecera*/
		$scope.limpiarCabeceraperiodos();
		 
		/*borrado datos*/
		if ( $.fn.dataTable.isDataTable( '#tableReporteEjecutivo' ) ) {
			oTable = $('#tableReporteEjecutivo').DataTable();
			oTable.clear();
			oTable.destroy();
		}
				
		$scope.validarFormulario();	
		
		if($scope.msjValidacion == ""){	
	
			var cols = $scope.definirNivelDetalle();
			
			$scope.showDialog = true;	
			setTimeout(function(){
				$http.post('./reporteejecutivo/generarReporteEjecutivo',$scope.reporteEjecutivo)
				.success(function(res,status) {     
					$scope.showDialog = false; 			
					$scope.mostrarExport = false; 
					var fechaInicio=$scope.reporteEjecutivo.fechaDesde;
					var fechaFin=$scope.reporteEjecutivo.fechaHasta;
					
					if($scope.reporteEjecutivo.periodo=="M"){ 
						var j=0;
						var mesInicio = 0;
						var mesFin = 0;
						mesInicio = fechaInicio.format("MM");						
						mesFin = fechaFin.format("MM");
						
						var anioInicioForm = fechaInicio.format("YYYY");						
						var anioFinForm = fechaFin.format("YYYY");
							
						if (mesInicio<=mesFin &&  anioInicioForm==anioFinForm){
							for (var i = mesInicio; i <= mesFin; i++) {
								j++;
								mes = $scope.generarListaMes(parseInt(i),anioInicioForm); 
								
								if(cols==undefined){
									cols=[{"name":mes}];
								}else{
									cols.push({"name":mes});
								}							
							}
						}else{
							for (var i = mesInicio; i <= 12; i++) {
								j++;
								mes= $scope.generarListaMes(parseInt(i),anioInicioForm); 
								
								if(cols==undefined){
									cols=[{"name":mes}];
								}else{
									cols.push({"name":mes});
								}							
							}						
								
							for (var i = 1; i <= mesFin; i++) {
								j++;
								mes= $scope.generarListaMes(parseInt(i),anioFinForm); 
								
								if(cols==undefined){
									cols=[{"name":mes}];
								}else{
									cols.push({"name":mes});
								}							
							}				
						}	
							 
					}else if($scope.reporteEjecutivo.periodo=="D"){
						var j=0;
						var diaInicio = 0;
						var diaFin = 0;
						diaInicio = fechaInicio.format("DD");
						diaFin = fechaFin.format("DD");
						var mesInicioForm = fechaInicio.format("MM");
						var mesFinForm = fechaFin.format("MM");
						
						if (diaInicio<=diaFin && mesInicioForm == mesFinForm){
							for (var i = diaInicio; i <= diaFin; i++) {
								j++;
								dia =  $scope.generarListaDia(i, fechaInicio.format("MM"), fechaInicio.format("YYYY"));
								if(cols==undefined){
									cols=[{"name":dia}];
								}else{
									cols.push({"name":dia});
								}							 
							}
						}else{
							var anioForm = fechaInicio.format("YYYY");
							var numeroDias = 0;
							numeroDias = $scope.numeroDiasPorMesYAnio(mesInicioForm, anioForm);
															
							for(var i = diaInicio; i<=numeroDias; i++){
								j++;
								dia = $scope.generarListaDia(i,fechaInicio.format("MM"), fechaInicio.format("YYYY"));
								if(cols==undefined){
									cols=[{"name":dia}];
								}else{
									cols.push({"name":dia});
								}							 
							}
							for(var i = 1; i<= diaFin; i++){
								j++;
								dia = $scope.generarListaDia(i,fechaFin.format("MM"), fechaFin.format("YYYY"));
								if(cols==undefined){
									cols=[{"name":dia}];
								}else{
									cols.push({"name":dia});
								}							 
							}							 
						}
							
					}	
					
					cantDef =0;
					cantDef = j;
					cols.push({"name":"Total"});
				
					cabeceras=cols;				
					
					/*borrado cabecera*/
					var cabeceraReporte = $("#headReporte");
					cabeceraReporte.children().remove();
					/*creacion de la head*/
					var cabeceraReporte = $("#headReporte");
					var row = $("<tr>");

					for (var n=0; n<cols.length; n++){
						row.append( $("<th>").text(cols[n].name) );
					}

					cabeceraReporte.append(row);
					
						
					if ( $.fn.dataTable.isDataTable( '#tableReporteEjecutivo' ) ) {//en caso ya exista hay que destruir
						oTable = $('#tableReporteEjecutivo').DataTable();
						oTable.destroy(); //se bdestruye
						var oTable;
						cant=0;
						var columnas = $scope.cargarEstructuraData();
						
						var i;
						for( i=0;res.resultado.length>i;i++){
							var cantidades = res.resultado[i].cadenaResul.split(",");
							var total=0;
							var j;
							for( j=0; (cantDef)>j; j++){
								total+= parseInt(cantidades[j]);
							}		
							var listCantidades=cantidades;
							listCantidades.splice(cantDef);//se quitan las demas columnas que no sean del valor
							listCantidades.push(total);	//se adicional el total al final 				
							res.resultado[i].cadenaResul = listCantidades;
						}
						   
						  oTable = $('#tableReporteEjecutivo').on( 'processing.dt', function ( e, settings, processing ) {
							$('#processingIndicator').css( 'display', processing ? 'block' : 'none' ); } ).DataTable( {
							//responsive: true,
							"scrollX": true, 
							"autoWidth": false,
							"processing": true, 
							destroy: true,//se crea de nuevo con los nuevos campos
							"dom": '<"top"ip>rt<"clear"><"bottom"l><"clear">',                                
							"language": {
								"url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
							},   
							"columns": columnas	
						}); 		
						 
						oTable.rows.add(res.resultado);
						oTable.draw();
						//oTable.columns.adjust().draw( false ); // adjust column sizing and redraw
						
				}else{			
					cant=0;
					var columnas = $scope.cargarEstructuraData();
					var i;
						for( i=0;res.resultado.length>i;i++){
							var cantidades = res.resultado[i].cadenaResul.split(",");
							var total=0;
							var j;
							for( j=0; (cantDef)>j; j++){
								total+= parseInt(cantidades[j]);
							}		
							var listCantidades=cantidades;
							listCantidades.splice(cantDef);//se quitan las demas columnas que no sean del valor
							listCantidades.push(total);	//se adicional el total al final 				
							res.resultado[i].cadenaResul = listCantidades;
						}
				  oTable = $('#tableReporteEjecutivo').on( 'processing.dt', function ( e, settings, processing ) {
							$('#processingIndicator').css( 'display', processing ? 'block' : 'none' ); } ).DataTable( {
						//responsive: true,
						"scrollX": true, 
						"autoWidth": false,
						"processing": true, 
						"dom": '<"top"ip>rt<"clear"><"bottom"l><"clear">', 
						"language": {
							"url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
						},
						"columns": columnas	
					});
								
						 oTable.clear();	 
						 
						
						
						oTable.rows.add(res.resultado);
						oTable.draw(); 
					 }
					 if(res.resultado.length > 0){
							var listadoTiposReporte = $scope.tiposReporte;
							var descripcionReporte;
							for(var i=0; i<listadoTiposReporte.length;i++){
								if(listadoTiposReporte[i].codigo == $scope.reporteEjecutivo.tipoReporte){
									descripcionReporte = listadoTiposReporte[i].descripcion;
								}
							}
							$('#descripcionReporte').html("- Reporte de "+descripcionReporte);
							$scope.mostrarExport = true;    
							$('.panel-collapse').collapse('hide');
					 }else{
							$scope.mostrarMsj = true;
							$scope.msjValidacion = "No hay resultados";  
					 }		 
								 
				   
				})
				.error(function (data, status) {
					$scope.showDialog = false;
					$scope.limpiarTabla();
					$scope.mostrarExport = false;
					$scope.mostrarMsj = true;
					$scope.msjValidacion = "Ocurrió un error al procesar la solicitud, por favor intentelo nuevamente.";
				});
		
			}, 500);	
			
		}
				
    }
 
 
    $scope.initForm = function (){
        $scope.$watch('reporteEjecutivo.codEntidad', function(codEntidad) {
            if (codEntidad){
                $scope.cargarSubEntidades(codEntidad);
				$scope.reporteEjecutivo.codSubEntidad = "00";
            }
        });
		
		/*cambios para no mostrar Subentidad en caso de reporte 1*/
		$scope.$watch('reporteEjecutivo.tipoReporte', function(tipoReporte) {
            if (tipoReporte == "reporteA"){
                ($('#nivelDetalle').children('option')[1]).setAttribute('disabled',true);
            }else{
				if(($('#nivelDetalle').children('option')[1]).getAttribute('disabled')){//rehabilitar si esta deshabilitado
					($('#nivelDetalle').children('option')[1]).removeAttribute('disabled');
				}
			}
        });
		/*cambios para no mostrar Subentidad en caso de reporte 1*/
		
    }
	
	   
	$scope.cargarDatosDefaultReporteEjecutivoForm();	
    $scope.cargarEntidades(); 
    $scope.cargarTipoDocumento();
	$scope.cargarAduana();
    $scope.cargarCuts();
	$scope.cargarPeriodo();
	$scope.cargarTipoReporte();
	$scope.cargarNivelesDetalle();	 
    $scope.initForm(); 
	
	 

	/*Inicio  de metodos de apoyo*/ 
	$scope.cargarEstructuraData = function(){
		var columnas = [{ data: 'entidad' }];
		if($scope.reporteEjecutivo.nivelDetalle == "detalleE"){
		}
		else if($scope.reporteEjecutivo.nivelDetalle == "detalleS" && $scope.reporteEjecutivo.tipoReporte != "reporteA"){//no aplica para el primer reporte
			columnas.push( { data: 'subEntidad' });
		}
		else if($scope.reporteEjecutivo.nivelDetalle == "detalleC"  && $scope.reporteEjecutivo.tipoReporte != "reporteA"){//restringir para el primer reporte
			columnas.push( { data: 'subEntidad' });
			columnas.push( { data: 'numCut' });
		}
		else if($scope.reporteEjecutivo.nivelDetalle == "detalleC"  && $scope.reporteEjecutivo.tipoReporte == "reporteA"){//restringir para el primer reporte
			columnas.push( { data: 'numCut' });
		}
		 
		for(var cantid=0; cantid<=(cantDef); cantid++){//el adicional es para pintar 
			columnas.push( {data: "cadenaResul."+cantid});
		}
		return columnas;
	}     
	
	$scope.definirNivelDetalle = function(){
		var cols = [{ "name": "Entidad" }];
	
		 
		if($scope.reporteEjecutivo.nivelDetalle == "detalleE"){
		}
		else if($scope.reporteEjecutivo.nivelDetalle == "detalleS"){
			cols.push( { "name": "Sub Entidad"});
		}
		else if($scope.reporteEjecutivo.nivelDetalle == "detalleC"){
			cols.push( { "name": "Sub Entidad"});
			cols.push(  { "name": "Numero Cut" });
		}
		return cols;
	}
	
	
 	$scope.generarListaMes = function(valor, anio){
		var refAnio = (" ").concat(anio);
		switch(valor){
					case 1: mes = "Enero".concat(refAnio);
						break;
					case 2: mes = "Febrero".concat(refAnio);
						break;
					case 3:	mes = "Marzo".concat(refAnio);
						break;
					case 4:	mes = "Abril".concat(refAnio);
						break;
					case 5:	mes = "Mayo".concat(refAnio);
						break;
					case 6:	mes = "Junio".concat(refAnio);
						break;
					case 7:	mes = "Julio".concat(refAnio);
						break;
					case 8:	mes = "Agosto".concat(refAnio);
						break;
					case 9: mes = "Setiembre".concat(refAnio);
						break;
					case 10: mes = "Octubre".concat(refAnio);
						break;
					case 11: mes = "Noviembre".concat(refAnio);
						break;
					case 12: mes = "Diciembre".concat(refAnio);
						break;
		}
		return mes;
	} 
	
	$scope.generarListaDia = function (valor, mesEnviado, anioEnviado){
		if((String(valor)).length<2){
			valor = "0".concat(String(valor));
		}
		return dia = valor+"/"+mesEnviado+"/"+anioEnviado;
	}
	
	$scope.numeroDiasPorMesYAnio = function (mesInicioForm, anioForm){
		var numeroDias = 0;
		
		if((mesInicioForm == 1) || (mesInicioForm == 3) || (mesInicioForm == 5) || (mesInicioForm == 7) 
			|| (mesInicioForm == 8 ) || (mesInicioForm == 10) || (mesInicioForm == 12) ){
								
			numeroDias=31;
						
		}else if((mesInicioForm == 4) || (mesInicioForm == 6) || (mesInicioForm == 9) || (mesInicioForm == 11)){
								
			numeroDias=30;
								
		}else if( mesInicioForm == 2){
							
			if($scope.esAnioBisiesto(anioForm)==true){//bisiestos
									
				numeroDias=29;
			}
			numeroDias= 28;				
		}
		
		return numeroDias;
	}
	
	$scope.esAnioBisiesto = function(anioForm){
		if(( ( ( anioForm % 4 ) == 0 ) && ( ( anioForm % 100 ) ) != 100 ) || ( ( anioForm % 400 ) == 0 ) ){//bisiestos
			return true;
		}else{
			return false;
		}
	}
	
}
 
function exportarExcel (){
    window.open("./reporteejecutivo/exportarExcel");
}

function exportarPdf (){
    window.open("./reporteejecutivo/exportarPdf");
}
 