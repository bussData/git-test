
	
	
	
	
function verDocumentoControl(tipoDocControl, numDocControl){
    $("#tableItemsVuce").find("tr:gt(0)").remove();
    $("#tableAnexosVuce").find("tr:gt(0)").remove();
    $("#tableDams").find("tr:gt(0)").remove();
    $("#myModalLoading").modal('show');
    setTimeout(function(){
        //$.get('./reportedetallado/cargarConsultaDocumentoVuce', {codTipo: '21', numDoc:'2016000067'}, function(data, status){
        $.get('./reportecerti/reportedetallado/cargarConsultaDocumentoVuce',
            {codTipo: tipoDocControl, numDoc:numDocControl}, function(data, status){
                $("#seccion2").hide();
                $("#seccion3").hide();
                $("#seccion4").hide();
                cargarSeccionCabecera(data);
                if(tipoDocControl == TIPO_DOC_DR){
                    $("#seccion2").show();
                    $("#seccion3").show();
                    $("#seccion4").show();
                    cargarSeccionDetalle(data);
                    cargarSeccionAnexo(data);
                    cargarSeccionDams(data);
                }

                $('#myModalLoading').on('hidden.bs.modal', function (e) {
                    $('#myModal').modal('show');
                })

                $("#myModalLoading").modal('hide');

            })
    }, 500);

}




function cargarSeccionCabecera(data){
    $('#subEntidadVuce').text(data.subEntidad);
    $('#subEntidadVuceDesc').text(data.subEntidadDesc);
    $('#tipoDocumentoVuce').text(data.tipo);
    $('#tipoDocumentoVuceDesc').text(data.tipoDocumentoDesc);
    $('#numeroDocumentoVuce').text(data.numeroDocumentoControl);
    $('#fechaInicioVigenciaVuce').text(data.fechaInicioVigencia == -62135751600000 ?
        "-" : moment(data.fechaInicioVigencia).format('DD/MM/YYYY'));
    $('#fechaFinVigenciaVuce').text(data.fechaFinVigencia == -62135751600000 ?
        "-" : moment(data.fechaFinVigencia).format('DD/MM/YYYY'));
    $('#fechaEmisionSuce').text(data.fechaDocumento == -62135751600000 ?
        "-" : moment(data.fechaDocumento).format('DD/MM/YYYY'));
    $('#tipoDocumentoTitularVuce').text(data.titularDRVuce.tipoDocumento);
    $('#tipoDocumentoTitularVuceDesc').text(data.titularDRVuce.tipoDocumentoDesc);
    $('#numeroDocumentoTitularVuce').text(data.titularDRVuce.numeroDocumento);
    $('#razonSocialTitularVuce').text(data.titularDRVuce.razonSocial);
    $('#aduanaVuce').text(data.codigoAduana);
    $('#aduanaVuceDesc').text(data.codAduanaDocumentoDesc);
    $('#cutVuce').text(data.numeroCUT);
    $('#cutVuceDesc').text(data.cutDesc);
}

function cargarSeccionDetalle(data){
    $.each(data.lstItems, function(i, item) {
        var $tr = $('<tr>').append(
            $('<td>').text(item.numeroSecuenciaSerie),
            $('<td>').text(item.numeroPartida),
            $('<td>').text(item.descripcionProducto)
        ).appendTo('#tableItemsVuce');
    });
}

function cargarSeccionAnexo(data){
    var  numeroDocumentoControl = data.numeroDocumentoControl;
    $.each(data.lstArchivosAnexos, function(i, item) {
        var urlcargarPDF = './reportecerti/reportedetallado/cargarPDFVUCE'+
            '?codigoIdDocAdjunto='+ item.codigoIdDocAdjunto+
            '&numeroDocumentoControl='+ numeroDocumentoControl+
            '&rndm='+ Math.random();
        var rutaURL = '<a href="'+urlcargarPDF+';">'+item.nombreDocAdjunto+'</a>';
        var $tr = $('<tr>').append(
            $('<td>').text(item.numeroSecuenciaDocAdjunto),
            $('<td>').html(rutaURL)
        ).appendTo('#tableAnexosVuce');
    });
}

function cargarSeccionDams(data){
    var seqTableDAms = 1;
    $.each(data.lstDeclaracionesAsociadas, function(i, item) {
        var dam = item.codAduana + "-" +
            item.annPresen + "-" +
            item.codRegimen + "-" +
            item.numDeclaracion;
        var urlcargarPDF = './reportecerti/reportedetallado/cargarConsultaDeclaracion?hdn_acceso=00'
            +'&hdn_num_declaracion='+ item.numDeclaracion
            +'&hdn_cod_aduana='+ item.codAduana
            +'&hdn_ann_presen='+ item.annPresen
            +'&hdn_cod_regimen='+ item.codRegimen;
        var rutaDamURL = '<a target="_blank" href="'+urlcargarPDF+'">'+dam+'</a>';
        var $tr = $('<tr>').append(
            $('<td>').text(seqTableDAms),
            $('<td>').html(rutaDamURL)
            //$('<td>').text(dam)
        ).appendTo('#tableDams');
        seqTableDAms++;
    });
}


    $scope.limpiar = function(){
        $scope.mostrarMsj = false;
        $scope.msjValidacion = "";
        $scope.reporteDetallado.codEntidad = "00";
        $scope.reporteDetallado.tipoDocTitularDR = "00";
        $scope.reporteDetallado.numeroDocTitularDR = "";
        $scope.reporteDetallado.tipoDoc = "00";
        $scope.reporteDetallado.numeroDoc = "";
        $scope.reporteDetallado.estadoDoc = "00";
        $scope.reporteDetallado.numeroCut = "00";
        $scope.reporteDetallado.fechaDesde = moment('01/01/0001','dd/MM/yyyy');
        $scope.reporteDetallado.fechaHasta = moment('01/01/0001','dd/MM/yyyy');
        if($scope.reporteDetallado.fechaDesde._i=="01/01/0001"){
            $('#fechaDesde').val("");
            $scope.reporteDetallado.fechaDesde=null;
        }
        if($scope.reporteDetallado.fechaHasta._i=="01/01/0001"){
            $('#fechaHasta').val("");
            $scope.reporteDetallado.fechaHasta=null;
        } 
        $scope.mostrarExport = false;
        $scope.limpiarTabla();
    }

	
	
      

	 

