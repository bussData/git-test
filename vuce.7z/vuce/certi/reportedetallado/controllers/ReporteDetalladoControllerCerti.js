'use strict';

var TIPO_DOC_DR = "21"

function ReporteDetalladoControllerCerti($scope, $http, $location) {

    var oTable; 
    $scope.showDialog = false;
    $scope.mostrarExport = false;

    $scope.cargarTipoEmision = function(){
         $http.get('/a/js/sigad/controladuanero2/ingreso/vuce/json/COA.json').then(function(response){
            $scope.tiposEmision = response.data;
        })
    }
	$scope.cargarMarca = function(){
         $http.get('/a/js/sigad/controladuanero2/ingreso/vuce/json/COB.json').then(function(response){
            $scope.marcas = response.data;
		})
    } 

	$scope.cargarTPIs = function(){
        $http.get('./reportedetallado/getTpisCOrigen').then(function(res){
            $scope.tpis = res.data;
        })
    }  
 
    $scope.cargarPais = function(codTpiCO){
        $http.get('./reportedetallado/getPaisesOrigen', {params: {'codElemento' : codTpiCO}}).then(function(res){
            $scope.paises = res.data;
        })
    } 
 
    $scope.cargarDatosDefaultReporteDetalladoForm = function(){
        $http.get('./reportedetallado/cargarDatosDefaultReporteDetalladoForm?rnd='+new Date().getTime())
            .then(function(res){
                $scope.reporteDetallado = res.data;
                $scope.reporteDetallado.fechaIniVigenciaCert = moment('01/01/0001','dd/MM/yyyy');
                $scope.reporteDetallado.fechaFinVigenciaCert = moment('01/01/0001','dd/MM/yyyy');
                $('#fechaIniVigenciaCert').val("");
                $('#fechaFinVigenciaCert').val("");
            });

    }

    $scope.initForm = function (){		

		$scope.$watch('reporteDetallado.codTpiCO', function(codTpiCO) {
            if (codTpiCO){
                $scope.cargarPais(codTpiCO);
                $scope.reporteDetallado.codPaisOrigen = "00";
            }
        });
        $(document).ready(function() {
            oTable = $('#tableReporteDetallado').DataTable( {
                responsive: true,
                "autoWidth": false,
                //"dom": '<lip<t>B>',
                "dom": '<"top"lip>rt<"clear">',
                "language": {
                    "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
                },
                "columns": [
                    { data: 'sec' },
                    { data: 'numeroCertOrigen' },
                    { data: 'fechaEmisionCert' },
                    { data: 'codEmision' },
                    { data: 'codTpiCO' },
                    { data: 'codPaisOrigen' },
                    { data: 'marcaCertOrigen' },
                    { data: 'numeroDeclaracion' },
                    { data: 'fechaNumeracion' },
					{ data: 'numeroDocImportadorCO' },
                    { data: 'nombreImportadorCO' },
					{
                        data: 'null' ,
                        "orderable": false,
                        "render" : function(data, type, full, meta){
                            var tipoEmision = full['codEmision'];
                            var numCertificado = full['numeroCertOrigen'];
                            return '<button class="btn btn-primary" onclick="verDocumentoControl('+codEmision+', '+numeroCertOrigen+')">Ver</button>';
                        }
                    }
                ]
            });
        });
    }

    $scope.cargarDatosDefaultReporteDetalladoForm(); 
	$scope.cargarTipoEmision();
	$scope.cargarMarca();
	$scope.cargarTPIs();
    $scope.initForm();
	
	 
    $scope.consultar  = function() {
        $scope.validarFormulario();

        if($scope.msjValidacion == ""){
            if($scope.reporteDetallado.fechaIniVigenciaCert!=null && $scope.reporteDetallado.fechaIniVigenciaCert._i=="01/01/0001"){
                $scope.reporteDetallado.fechaIniVigenciaCert=null;
            }
            if($scope.reporteDetallado.fechaFinVigenciaCert!=null && $scope.reporteDetallado.fechaFinVigenciaCert._i=="01/01/0001"){
                $scope.reporteDetallado.fechaFinVigenciaCert=null;
            }
            $scope.showDialog = true;
            setTimeout(function(){
                $http.post('./reportedetallado/generarReporteDetallado',$scope.reporteDetallado)
                    .success(function(res,status) {
                        $scope.showDialog = false;
                        $scope.limpiarTabla();
                        $scope.mostrarMsj = false;
                        $scope.msjValidacion = "";
                        $scope.mostrarExport = false;
                        if(angular.isDefined(res.msjError)){
                            $scope.msjValidacion = res.msjError;
                        } else if (res.resultado.length <= 0){
                            $scope.mostrarMsj = true;
                            $scope.msjValidacion = "No hay resultados";
                        } else {
                            $scope.reporteDetallado.resultado = res.resultado;
                            var table = $('#tableReporteDetallado').DataTable();
                            table.rows.add(res.resultado);
                            table.draw();
                            $scope.mostrarExport = true;
                            $('#collapseOne').collapse('hide');
                        }

                    })
                    .error(function (data, status) {
                            $scope.showDialog = false;
                            $scope.limpiarTabla();
                            $scope.mostrarExport = false;
                            $scope.mostrarMsj = true;
                            $scope.msjValidacion = "Ocurrio un error al procesar la solicitud, por favor intentelo nuevamente.";
                        }
                    );
            }, 500);
        }
        
		
		$scope.limpiarTabla = function(){
			oTable.clear();
			oTable.draw();
		}
    }
	
	
	/***
Que como minimo se haya seleccionado alguno de los siguientes filtros:
1.	N�mero del Certificado de Origen
2.	Fecha de B�squeda con un rango no mayor a 1 a�o.
Cuando se seleccionen los otros criterios de b�squeda si adicionalmente no se ha especificado �Fecha de B�squeda� por defecto calcular� el plazo solo por 1 a�o 
Caso contrario se muestra un mensaje de excepci�n 01.

El rango de fecha de b�squeda no debe exceder de 1 a�o. Caso contrario se muestra un mensaje de excepci�n 02.
**/
    $scope.validarFormulario = function(){
        $scope.mostrarMsj = false;
        $scope.msjValidacion = "";

        var fechaDesdeForm = $scope.reporteDetallado.fechaIniVigenciaCert;
        var fechaHastaForm = $scope.reporteDetallado.fechaFinVigenciaCert;
        var nroDoc = $scope.reporteDetallado.numeroCertOrigen;

        //1. minimo enviar numero de documento o rango de fechas
        if( !$scope.esValido(nroDoc) && ( !$scope.esFechaValida(fechaDesdeForm) || !$scope.esFechaValida(fechaHastaForm) )){
            $scope.mostrarMsj = true;
            $scope.msjValidacion = "Debe seleccionar el n�mero del certificado de origen o la fecha de b�squeda como minimo.";
            return false;
        }
 
		//3. los otros criterios de b�squeda si adicionalmente no se ha especificado �Fecha de B�squeda� por defecto calcular� el plazo solo por 1 a�o 
        if( $scope.esValido(nroDoc) && ( !$scope.esFechaValida(fechaDesdeForm) || !$scope.esFechaValida(fechaHastaForm) )){
			var cantdiasmaxFecha = 365;
			$scope.reporteDetallado.fechaIniVigenciaCert =  moment().format("DD-MM-YYYY");
			var newDesde = $scope.reporteDetallado.fechaIniVigenciaCert;
			var fechaMinSimple = moment(newDesde, "DD-MM-YYYY").subtract(cantdiasmaxFecha, 'days');
			$scope.reporteDetallado.fechaFinVigenciaCert = fechaMinSimple();
         }
		
        if($scope.esFechaValida(fechaDesdeForm) || $scope.esFechaValida(fechaHastaForm)){
            //validacion del rango:
            if(moment(fechaDesdeForm).isAfter(fechaHastaForm)){
                $scope.mostrarMsj = true;
                $scope.msjValidacion = "La fecha inicial de Busqueda debe ser menor a la fecha de fin";
                return false;
            }
			
            //2. rango maximo de fechas 365 dias
            var cantdiasmaxAdicional = 365;
            var fechaMaxAdicional = moment(fechaDesdeForm, "DD-MM-YYYY").add(cantdiasmaxAdicional, 'days');
            if(moment(fechaHastaForm).isAfter(fechaMaxAdicional)){
                $scope.mostrarMsj = true;
                $scope.msjValidacion = "El rango de fecha de busqueda maximo es de 1 a�o.";
                return false;
            }
		} 
           
    }
		
    $scope.esValido = function(campo){
        if(campo != undefined && campo != null && campo != '' && campo != '00' ){
            return true;
        }
        return false;
    }

    $scope.esFechaValida = function(campo){
        if(campo != undefined && campo != null && campo._i !="01/01/0001" ){
            return true;
        }
        return false;
    }
    
	
}



function exportarExcel (){
    window.open("./reportecerti/reportedetallado/exportarExcel");
}

function exportarPdf (){
    window.open("./reportecerti/reportedetallado/exportarPdf");
}