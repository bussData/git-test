var ReporteDetalladoVuceCertiApp = angular.module('ReporteDetalladoVuceCertiApp', []);
ReporteDetalladoVuceCertiApp.config(['$routeProvider', function($routes) {

    $routes
        .when('/form_reportedetalladovucecerti', {
            templateUrl	: '/a/js/sigad/controladuanero2/ingreso/vuce/certi/reportedetallado/components/FormReporteDetalladoVuceCerti.html',
            controller 	: 'ReporteDetalladoControllerCerti'
        })
        .otherwise({
            redirectTo: '/form_reportedetalladovucecerti'
        });

}]);

var dateTimePicker = function($filter) {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attrs, ngModelCtrl) {
            var parent = $(element).parent();
            var dtp = parent.datetimepicker({
                useCurrent: false,
                format: "L",
                language: 'es-PE',
                pickTime: false
            });

            ngModelCtrl.$formatters.unshift(function(v) {
                return $filter('date')(v,'dd/MM/yyyy'); 
            });

            if (ngModelCtrl) {
                ngModelCtrl.$render = function () {
                    setPickerValue();
                };
            }

            function setPickerValue() {
                var date = new moment('01/01/0001','dd/MM/yyyy');
                if (ngModelCtrl && ngModelCtrl.$viewValue) {
                    date = ngModelCtrl.$viewValue;
                }
				if(ngModelCtrl.$modelValue==null || (ngModelCtrl.$modelValue!=undefined && ngModelCtrl.$modelValue._i=="01/01/0001")){//para setear fecha empty
					dtp.data('DateTimePicker').setDate(moment('01/01/0001','dd/MM/yyyy'));//si va null, por defecto le coloca la del dia.
					$('#fechaDesde').val("");
					$('#fechaHasta').val("");
				}else{
					dtp.data('DateTimePicker').setDate(date);
				}
            }

            dtp
            .on("dp.change", function (ev) {
                if (ngModelCtrl) {
                    ngModelCtrl.$setViewValue(moment(ev.date));    
                }
            })
            .datetimepicker(); 
        }
    };
}
/*
var modalShow = function ($parse) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.showModal = function (visible, elem) {
                if (!elem)
                    elem = element;

                if (visible){
                    $(elem).modal({
                        "show" : true,
                        "backdrop" : 'static'
                    }); 
                } else {
                    $(elem).modal("hide");
                }
            }

            //Watch for changes to the modal-visible attribute
            scope.$watch(attrs.modalShow, function (newValue, oldValue) {
                scope.showModal(newValue, attrs.$$element);
            });

            //Update the visible value when the dialog is closed through UI actions (Ok, cancel, etc.)
            $(element).bind("hide.bs.modal", function () {
                $parse(attrs.modalShow).assign(scope, false);
                if (!scope.$$phase && !scope.$root.$$phase)
                    scope.$apply();
            });
        }

    };
}


ReporteDetalladoVuceCertiApp.directive("modalShow", modalShow);*/
ReporteDetalladoVuceCertiApp.directive('dateTimePicker', dateTimePicker);