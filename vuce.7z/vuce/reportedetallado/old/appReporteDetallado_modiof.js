var ReporteDetalladoVuceApp = angular.module('ReporteDetalladoVuceApp', []);
ReporteDetalladoVuceApp.config(['$routeProvider', function($routes) {

    $routes
        .when('/form_reportedetalladovuce', {
            templateUrl	: '/a/js/sigad/controladuanero2/ingreso/vuce/reportedetallado/components/FormReporteDetalladoVuce.html',
            controller 	: 'ReporteDetalladoController'
        })
        .otherwise({
            redirectTo: '/form_reportedetalladovuce'
        });

}]);

var dateTimePicker = function($filter) {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attrs, ngModelCtrl) {
            var parent = $(element).parent();
            var dtp = parent.datetimepicker({
                useCurrent: false,
                format: "L",
                language: 'es-PE',
                pickTime: false
            });

            ngModelCtrl.$formatters.unshift(function(v) {
				if(v!=null && !v.isValid()){
					return null;
				}else{
                return $filter('date')(v,'dd/MM/yyyy'); 
				}
            });

            if (ngModelCtrl) {
                ngModelCtrl.$render = function () {
                    setPickerValue();
                };
            }

            function setPickerValue() {
                var date = null;
                if (ngModelCtrl && ngModelCtrl.$viewValue) {
                    date = ngModelCtrl.$viewValue;
                }

                if(date!=null){
					dtp.data('DateTimePicker').setDate(date);
				}else{
					//dpt.data('DateTimePicker').setDate(null);
				}
            }
 
            dtp.on("dp.change", function (ev) {
                if (ngModelCtrl) {
                    ngModelCtrl.$setViewValue(moment(ev.date));    
                }
            })
            .datetimepicker();
			/*$('.input-group.date').each(function() {
				$(this).datetimepicker().on('dp.change', function (ev,v) {
				if(v!=null && v.isValid()){
						if (ngModelCtrl && ngModelCtrl.$viewValue==null || (ngModelCtrl.$viewValue!=null  && ngModelCtrl.$viewValue._d=="Invalid Date")) {
							ngModelCtrl.$setViewValue(moment(ev.date));    
						} 
					});
				}
			})*/
        }
    };
}

var modalShow = function ($parse) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            scope.showModal = function (visible, elem) {
                if (!elem)
                    elem = element;

                if (visible){
                    $(elem).modal({
                        "show" : true,
                        "backdrop" : 'static'
                    }); 
                } else {
                    $(elem).modal("hide");
                }
            }

            //Watch for changes to the modal-visible attribute
            scope.$watch(attrs.modalShow, function (newValue, oldValue) {
                scope.showModal(newValue, attrs.$$element);
            });

            //Update the visible value when the dialog is closed through UI actions (Ok, cancel, etc.)
            $(element).bind("hide.bs.modal", function () {
                $parse(attrs.modalShow).assign(scope, false);
                if (!scope.$$phase && !scope.$root.$$phase)
                    scope.$apply();
            });
        }

    };
}


ReporteDetalladoVuceApp.directive("modalShow", modalShow);
ReporteDetalladoVuceApp.directive('dateTimePicker', dateTimePicker);