'use strict';

var TIPO_DOC_DR = "21"
var tipoDocControl;
var promise;
var  numDocControl;
function ReporteDetalladoController($scope, $http, $location) {

    var oTable;
    //$scope.showModal2 = false;
    $scope.showDialog = false;
    $scope.mostrarExport = false;

    $scope.cargarEntidades = function(){
        $http.get('./reportedetallado/getEntidades').then(function(res){
            $scope.entidades = res.data;
        })
    }

    $scope.cargarSubEntidades = function(codEntidad){
        $http.get('./reportedetallado/getSubEntidades', {params : {'codElemento' : codEntidad}}).then(function(res){
            $scope.subentidades = res.data;
        })
    }

    $scope.cargarCuts = function(){
        $http.get('./reportedetallado/getCuts').then(function(res){
            $scope.cuts = res.data;
        })
    }

    $scope.cargarTipoDocumento = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/vuce/json/75.json').then(function(response){
            $scope.tiposDocumento = response.data;      
        })
    }

    $scope.cargarTipoDocumentoTitular = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/vuce/json/27.json').then(function(response){
            $scope.tiposDocumentoTitular = response.data;           
        })
    }

    $scope.cargarEstadosDocumento = function(){
        $http.get('/a/js/sigad/controladuanero2/ingreso/vuce/json/546.json').then(function(response){
            $scope.estadosDocumento = response.data;           
        })
    }

    $scope.cargarDatosDefaultReporteDetalladoForm = function(){
        $http.get('./reportedetallado/cargarDatosDefaultReporteDetalladoForm?rnd='+new Date().getTime())
            .then(function(res){
                $scope.reporteDetallado = res.data;		
				$scope.reporteDetallado.fechaDesde = moment('01/01/0001','dd/MM/yyyy');
				$scope.reporteDetallado.fechaHasta = moment('01/01/0001','dd/MM/yyyy');  
				$('#fechaDesde').val(""); 
				$('#fechaHasta').val(""); 						
        });	 
		 
    }


    $scope.consultar  = function() {
        $scope.validarFormulario();
		
		if($scope.msjValidacion == ""){
			if($scope.reporteDetallado.fechaDesde!=null && $scope.reporteDetallado.fechaDesde._i=="01/01/0001"){
				$scope.reporteDetallado.fechaDesde=null;
			}
			if($scope.reporteDetallado.fechaHasta!=null && $scope.reporteDetallado.fechaHasta._i=="01/01/0001"){
				$scope.reporteDetallado.fechaHasta=null;
			}
			$scope.showDialog = true;
            setTimeout(function(){
                $http.post('./reportedetallado/generarReporteDetallado',$scope.reporteDetallado)
                    .success(function(res,status) {
                        $scope.showDialog = false;
                        $scope.limpiarTabla();
                        $scope.mostrarMsj = false;
                        $scope.msjValidacion = "";
                        $scope.mostrarExport = false;
                        if(angular.isDefined(res.msjError)){                   
                            $scope.msjValidacion = res.msjError;
                        } else if (res.resultado.length <= 0){
                            $scope.mostrarMsj = true;
                            $scope.msjValidacion = "No hay resultados";
                        } else {                        
                            $scope.reporteDetallado.resultado = res.resultado;
                            var table = $('#tableReporteDetallado').DataTable();
                            table.rows.add(res.resultado);                    
                            table.draw();
                            $scope.mostrarExport = true;    
                            $('#collapseOne').collapse('hide');
                        }
                        
                    })
                    .error(function (data, status) {
                        $scope.showDialog = false;
                        $scope.limpiarTabla();
                        $scope.mostrarExport = false;
                        $scope.mostrarMsj = true;                    
                        $scope.msjValidacion = "Ocurrio un error al procesar la solicitud, por favor intentelo nuevamente.";
                    }
                );
            }, 500);
        }
        //}
    }

    $scope.validarFormulario = function(){
        $scope.mostrarMsj = false;
        $scope.msjValidacion = "";
         
        var fechaDesdeForm = $scope.reporteDetallado.fechaDesde;
        var fechaHastaForm = $scope.reporteDetallado.fechaHasta;
        var nroDoc = $scope.reporteDetallado.numeroDoc;
        
        //1. minimo enviar numero de documento o rango de fechas
        if( !$scope.esValido(nroDoc) && ( !$scope.esFechaValida(fechaDesdeForm) || !$scope.esFechaValida(fechaHastaForm) )){
            $scope.mostrarMsj = true;
            $scope.msjValidacion = "Debe indicar el número de documento de 10 caracteres o la fecha de busqueda como minimo";
            return false;
        }

        
        if($scope.esFechaValida(fechaDesdeForm) || $scope.esFechaValida(fechaHastaForm)){
            //validacion del rango:
            if(moment(fechaDesdeForm).isAfter(fechaHastaForm)){
                $scope.mostrarMsj = true;
                $scope.msjValidacion = "La fecha inicial de Busqueda debe ser menor a la fecha de fin";
                return false;
            }  

            //3. rango maximo de fechas 180 dias, por lo menos entidad y subentidad, tipo y numero doc titular ó numero de cut
            var cantdiasmaxAdicional = 180;
            var fechaMaxAdicional = moment(fechaDesdeForm, "DD-MM-YYYY").add(cantdiasmaxAdicional, 'days');
            if(moment(fechaHastaForm).isAfter(fechaMaxAdicional)){
                $scope.mostrarMsj = true;
                $scope.msjValidacion = "El rango de fecha de busqueda maximo es de 180 dias.";
                return false;
            }
            

            var entidadForm = $scope.reporteDetallado.codEntidad;
            var subEntidadForm=$scope.reporteDetallado.codSubEntidad;
            var tipoForm=$scope.reporteDetallado.tipoDocTitularDR;
            var nroTitularForm=$scope.reporteDetallado.numeroDocTitularDR;
            var nroCutForm=$scope.reporteDetallado.numeroCut;
            
            
            //2. si solo ingresa rango de fechas maximo 31 dias
            var cantdiasmaxFecha = 31;
            var fechaMaxSimple = moment(fechaDesdeForm, "DD-MM-YYYY").add(cantdiasmaxFecha, 'days');
            if(moment(fechaHastaForm).isAfter(fechaMaxSimple)){
                if( 
                    (!$scope.esValido(entidadForm) || !$scope.esValido(subEntidadForm)) &&

                    (!$scope.esValido(tipoForm) || !$scope.esValido(nroTitularForm)) && 

                    !$scope.esValido(nroCutForm) ){

                    $scope.mostrarMsj = true;
                    $scope.msjValidacion = "Para rangos de fecha de búsqueda mayores a 31 dias, seleccione Entidad y Subentidad o Tipo y numero de documento del titular o Numero de CUT.";
                    return false;
                }
            }    
        }
    }
    
    $scope.esValido = function(campo){
        if(campo != undefined && campo != null && campo != '' && campo != '00' ){
            return true;
        }
        return false;
    }

	$scope.esFechaValida = function(campo){
		if(campo != undefined && campo != null && campo._i !="01/01/0001" ){
            return true;
        }
        return false;
	}
/*
    $scope.validarFormulario = function(datosIngresados){
        //1. minimo enviar numero de documento o rango de fechas
        alert(moment(datosIngresados.fechaDesde).startOf('day').isValid());
        //alert(datosIngresados.fechaDesde.getTime());
        if(
        (datosIngresados.fechaDesde == undefined || datosIngresados.fechaDesde == null ||
         datosIngresados.fechaDesde == '')
        || 
        (datosIngresados.fechaHasta == undefined || datosIngresados.fechaHasta == null ||
        datosIngresados.fechaHasta == '')
        ){
            alert('fechas');
        }
        //2. si solo ingresa rango de fechas maximo 31 dias
        //3. rango maximo de fechas 180 dias, por lo menos entidad y subentidad, 
        tipo y numero doc titular ó numero de cut
        alert('hey')
        return true;

    }

    $scope.validarFechas = function (fechaDesde, fechaHasta){
        fechaDesde = moment(fechaDesde).startOf('day');
        fechaHasta = moment(fechaHasta).startOf('day');
        if((fechaDesde).isAfter(fechaHasta, 'day')){
            $scope.mostrarMsj = true;
            $scope.msjValidacion = "La fecha de búsqueda Desde no puede ser mayor a la fecha Hasta.";
            return false;
        } else if (Math.abs(fechaDesde.diff(fechaHasta, 'days')) > 31){
            $scope.mostrarMsj = true;
            $scope.msjValidacion = "Para rangos de fecha de búsqueda mayores a 31 días, seleccione Entidad y Subentidad ó Tipo y número de documento del titular ó Número de CUT";
            return false;
        }
        return true;        
    }*/


    $scope.limpiar = function(){     
        $scope.mostrarMsj = false;   
        $scope.msjValidacion = "";
        $scope.reporteDetallado.codEntidad = "00";
        $scope.reporteDetallado.tipoDocTitularDR = "00";
        $scope.reporteDetallado.numeroDocTitularDR = "";
        $scope.reporteDetallado.tipoDoc = "00";
        $scope.reporteDetallado.numeroDoc = "";
        $scope.reporteDetallado.estadoDoc = "00";
        $scope.reporteDetallado.numeroCut = "00";
        $scope.reporteDetallado.fechaDesde = moment('01/01/0001','dd/MM/yyyy');
        $scope.reporteDetallado.fechaHasta = moment('01/01/0001','dd/MM/yyyy');
        if($scope.reporteDetallado.fechaDesde._i=="01/01/0001"){
			$('#fechaDesde').val("");
			$scope.reporteDetallado.fechaDesde=null;
		}
		if($scope.reporteDetallado.fechaHasta._i=="01/01/0001"){
			$('#fechaHasta').val("");
			$scope.reporteDetallado.fechaHasta=null;
		} 
		//$scope.reporteDetallado.fechaDesde = moment(new Date());
        //$scope.reporteDetallado.fechaHasta = moment(new Date());
        $scope.mostrarExport = false;
        $scope.limpiarTabla();        
    }

    $scope.limpiarTabla = function(){
        oTable.clear();
        oTable.draw();
    }

    $scope.initForm = function (){
        $scope.$watch('reporteDetallado.codEntidad', function(codEntidad) {
            if (codEntidad){
                $scope.cargarSubEntidades(codEntidad);
                $scope.reporteDetallado.codSubEntidad = "00";
            } 
        });
		 
		
        $(document).ready(function() {
            oTable = $('#tableReporteDetallado').DataTable( {
                responsive: true,
                "autoWidth": false,
                //"dom": '<lip<t>B>',
                "dom": '<"top"lip>rt<"clear">',
                "language": {
                    "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
                },                
                "columns": [
                    { data: 'sec' },
                    { data: 'entidad' },
                    { data: 'subEntidad' },
                    { data: 'tipoDocControl' },
                    { data: 'numDocControl' },
                    { data: 'estadoDocControl' },
                    { data: 'numCut' },
                    { data: 'fechaIniVigenciaDocControl' },
                    { data: 'fechaFinVigenciaDocControl' },
                    { data: 'tipoDocTitular' },
                    { data: 'numDocTitular' },
                    { 
                        data: 'null' ,
                        "orderable": false,
                        "render" : function(data, type, full, meta){
                            var tipoDocControl = full['tipoDocControl'].substring(0,2);
                            var numDocControl = full['numDocControl'];
                            return '<button class="btn btn-primary" onclick="verDocumentoControl('+tipoDocControl+', '+numDocControl+')">Ver</button>';
                        }
                    }
                ]
            });
        });
		
    }

    $scope.cargarDatosDefaultReporteDetalladoForm();
    $scope.cargarEntidades();
    $scope.cargarTipoDocumento();
    $scope.cargarTipoDocumentoTitular();
    $scope.cargarEstadosDocumento();
    $scope.cargarCuts();
    $scope.initForm(); 
	
	

	
}

/*function verDocumentoControl(tipoDocControl, numDocControl){
		 cargarDocs(tipoDocControl, numDocControl);
			//cargarAnexos(tipoDocControl, numDocControl) 
     
}*/
/*

$.when( verDocumentoControl(tipoDocControl, numDocControl)).then(
		   function( status ) {
			 var msg="<h3>"+status + ", things are going well</h3>";
			 $( "#tableAnexosVuce" ).append(msg);
		  },
		  function( status ) {
			$( "#tableAnexosVuce" ).append( status );
			loaddd();
		  }
);*/
function verDocumentoControl(tipoDocControl, numDocControl){
    $("#tableItemsVuce").find("tr:gt(0)").remove();
    $("#tableAnexosVuce").find("tr:gt(0)").remove();
    $("#tableDams").find("tr:gt(0)").remove();    
    $("#myModalLoading").modal('show'); 
	
	 
    setTimeout(function(){
        //$.get('./reportedetallado/cargarConsultaDocumentoVuce', {codTipo: '21', numDoc:'2016000067'}, function(data, status){
		 
        $.get('./reportedetallado/cargarConsultaDocumentoVuce', 
            {codTipo: tipoDocControl, numDoc:numDocControl}, function(data, status){            
            $("#seccion2").hide();
            $("#seccion3").hide();
            $("#seccion4").hide();
            cargarSeccionCabecera(data);
            if(tipoDocControl == TIPO_DOC_DR){
                $("#seccion2").show();
                $("#seccion3").show();
                $("#seccion4").show();
                cargarSeccionDetalle(data);
                //cargarSeccionAnexo(data);
                cargarSeccionDams(data);
				 
            }            
            
            $('#myModalLoading').on('hidden.bs.modal', function (e) {
                $('#myModal').modal('show');
            }) 
            $("#myModalLoading").modal('hide');
			
			
			//mostrar los anexos:
			$("#myDivLoading").modal('show');
			
			 //despues que muestra la ventana correctamente ya busca los anexos:
			$('#myModal').on('shown.bs.modal', function () { 
				
				if(status=="success"){
					cargarSeccionAnexoNew(data);
					/*setTimeout(function() {*/
					//console.log("es momento de ejecutar la segunda fase");
					// $( "#testConDelay" ).append( "es momento de ejecutar la segunda fase" );
					 
					//console.log("inicia load"); 
					 //desaparecer el loading y mostrar la carga 
					//$('#anexosVuce').modal('show');
					//loaddd();
					/*}, Math.floor( 4000 ) );*/
     
				}
			});
        }); 
		
     
   }, 5000);     
	
}


function loaddd(){
	for(var i=0; i<=5; i++){
	var msj= "<span>"+i+",</span>";
		$( "#testConDelay" ).append(msj);
		i++;
	}
}
/*
function ejecutaDespues(){
 setTimeout(function() {
      //  $http.get('./reportedetallado/cargarConsultaDocumentoVuceAnexos', {codTipo:tipoDocControl, numDoc:numDocControl}).then(function(response){})
		
      }, Math.floor( 8000 ) );
}*//*
 $.when(ejecutaDespues()).then( 
	function( status ) {
	console.log("entra");
        $( "#testConDelay" ).append( status );
		console.log("termina");
      }
    );*/
				
				
function cargarSeccionAnexoNew(data){
	var  numeroDocumentoControl = data!=null?data.numeroDocumentoControl:""; 
	  
	  $.get('./reportedetallado/cargarConsultaDocumentoVuceAnexos', 
            {codTipo: data.tipo, numDoc:data.numeroDocumentoControl}, function(data, status){  
			if(data!=null && data.lstArchivosAnexos!=null && data.lstArchivosAnexos!=undefined){
				$.each(data.lstArchivosAnexos, function(i, item) {
					var urlcargarPDF = './reportedetallado/cargarPDFVUCE'+		
							'?numeroSecuenciaDocAdjunto='+ item.numeroSecuenciaDocAdjunto+
							'&numeroDocumentoControl='+ numeroDocumentoControl+
							'&rndm='+ Math.random();
					var rutaURL = '<a href="'+urlcargarPDF+';">'+item.nombreDocAdjunto+'</a>';
					var $tr = $('<tr>').append(
						$('<td>').text(item.numeroSecuenciaDocAdjunto),
						$('<td>').html(rutaURL)
					).appendTo('#tableAnexosVuce');
				});
				}
			});
	 
					$("#myDivLoading").modal('hide');
	 // $("#myDivLoading").hide();
	
}
 /*$.when( $('#tableItemsVuce')).done(  function (){
	 loaddd()
        //$( "#tableAnexosVuce" ).html( "<p>SIGUIE CARGABNDIO</p>" )
     //cargarSeccionAnexo(data)
   });*/
  /* myDeferred.addCallback(function(value) {
          $( "#tableAnexosVuce" ).html( "<p>SIGUIE CARGABNDIO</p>" )
         
      });*/

function loaddd(){
	for(var i=0; i<=5; i++){
	var msj= "<span>"+i+",</span>";
		$( "#tableAnexosVuce" ).append(msj);
		i++;
	}
}
function cargarSeccionCabecera(data){
    $('#subEntidadVuce').text(data.subEntidad);
    $('#subEntidadVuceDesc').text(data.subEntidadDesc);
    $('#tipoDocumentoVuce').text(data.tipo);
    $('#tipoDocumentoVuceDesc').text(data.tipoDocumentoDesc);
    $('#numeroDocumentoVuce').text(data.numeroDocumentoControl);
    $('#fechaInicioVigenciaVuce').text(data.fechaInicioVigencia == -62135751600000 ? 
        "-" : moment(data.fechaInicioVigencia).format('DD/MM/YYYY'));
    $('#fechaFinVigenciaVuce').text(data.fechaFinVigencia == -62135751600000 ? 
        "-" : moment(data.fechaFinVigencia).format('DD/MM/YYYY'));
    $('#fechaEmisionSuce').text(data.fechaDocumento == -62135751600000 ? 
        "-" : moment(data.fechaDocumento).format('DD/MM/YYYY'));
    $('#tipoDocumentoTitularVuce').text(data.titularDRVuce!=undefined ? data.titularDRVuce.tipoDocumento:"");
    $('#tipoDocumentoTitularVuceDesc').text(data.titularDRVuce!=null? data.titularDRVuce.tipoDocumentoDesc:"");
    $('#numeroDocumentoTitularVuce').text(data.titularDRVuce!=null? data.titularDRVuce.numeroDocumento:"");
    $('#razonSocialTitularVuce').text(data.titularDRVuce!=null? data.titularDRVuce.razonSocial:"");
    $('#aduanaVuce').text(data.codigoAduana);
    $('#aduanaVuceDesc').text(data.codAduanaDocumentoDesc);
    $('#cutVuce').text(data.numeroCUT);
    $('#cutVuceDesc').text(data.cutDesc);
}

function cargarSeccionDetalle(data){
    $.each(data.lstItems, function(i, item) {
        var $tr = $('<tr>').append(
            $('<td>').text(item.numeroSecuenciaSerie),
            $('<td>').text(item.numeroPartida),
            $('<td>').text(item.descripcionProducto)
        ).appendTo('#tableItemsVuce');
    });
}

function cargarSeccionAnexo(data){
	var  numeroDocumentoControl = data!=null?data.numeroDocumentoControl:"";
	  $("#myDivLoading").hide();
	if(data!=null && data.lstArchivosAnexos!=null && data.lstArchivosAnexos!=undefined){
    $.each(data.lstArchivosAnexos, function(i, item) {
        var urlcargarPDF = './reportedetallado/cargarPDFVUCE'+		
                '?numeroSecuenciaDocAdjunto='+ item.numeroSecuenciaDocAdjunto+
				'&numeroDocumentoControl='+ numeroDocumentoControl+
                '&rndm='+ Math.random();
        var rutaURL = '<a href="'+urlcargarPDF+';">'+item.nombreDocAdjunto+'</a>';
        var $tr = $('<tr>').append(
            $('<td>').text(item.numeroSecuenciaDocAdjunto),
            $('<td>').html(rutaURL)
        ).appendTo('#tableAnexosVuce');
    });
	}
}

function cargarSeccionDams(data){
    var seqTableDAms = 1;
    $.each(data.lstDeclaracionesAsociadas, function(i, item) {
        var dam = item.codAduana + "-" +
        item.annPresen + "-" +
        item.codRegimen + "-" +
        item.numDeclaracion;
                     /*linkDua = "http://www.aduanet.gob.pe/servlet/SgCDUI2?codaduana=".concat(aduana).concat(
             "&anoprese=").concat(ano).concat("&numecorre=").concat(
             numecorre).concat("&n=").concat(regimen);
             return linkDua;*/
        var urlcargarPDF = './reportedetallado/cargarConsultaDeclaracion?hdn_acceso=00'
                +'&hdn_num_declaracion='+ item.numDeclaracion
                +'&hdn_cod_aduana='+ item.codAduana
                +'&hdn_ann_presen='+ item.annPresen
                +'&hdn_cod_regimen='+ item.codRegimen;
        /*var linkDam ="http://www.aduanet.gob.pe/servlet/SgCDUI2?codaduana="+
        item.codAduana+"&anoprese="+item.annPresen+"&numecorre="+
        item.numDeclaracion+"&n="+item.codRegimen;*/
        //var rutaDamURL = '<a target="_blank" href="'+linkDam+'">'+dam+'</a>';
        var rutaDamURL = '<a target="_blank" href="'+urlcargarPDF+'">'+dam+'</a>';
        var $tr = $('<tr>').append(
            $('<td>').text(seqTableDAms),
            $('<td>').html(rutaDamURL)
            //$('<td>').text(dam)
        ).appendTo('#tableDams');
        seqTableDAms++;
    });        
}

function exportarExcel (){
    window.open("./reportedetallado/exportarExcel");
}

function exportarPdf (){
    window.open("./reportedetallado/exportarPdf");
}